# Logical Operators
# Logical Operators works with only bulian(0- False / 1 - True) value
# A   B   O (AND)
# ------------
# 0   0   0
# 0   1   0
# 1   0   0
# 1   1   1

# a=121
# b=30
# c=10
# print((a>b) and (b>c)) 

# A   B   O (OR)
# ------------
# 0   0   0
# 0   1   1
# 1   0   1
# 1   1   1


# a=121
# b=30
# c=10
# print((a>b) or (b>c)) 

# A     O (NOT)
# ------------
# 0     1
# 1     0

# a=101
# b=12

# print(not(a<b))

# identity operators (is  ----- is not)

# x=["kamal","Rahim"]
# y=["Kamal","Rahim"]
# x=y

# # print(x is  y)
# print(x is not y)
# Membership Operators (in ------- not in)
# x=['apple','banana','guava']

# print('guavaa' not in x)

# Bitwise Operators (and= & , or=|, xor= ^, not= ~, shift left = << , shift right =  >>)

    # 0   0   0   0   -   0
    # 0   0   0   1   -   1
    # 0   0   1   0   -   2
    # 0   0   1   1   -   3
    # 0   1   0   0   -   4
    # 0   1   0   1   -   5
    # 0   1   1   0   -   6
    # 0   1   1   1   -   7
    # 1   0   0   0   -   8
    # 1   0   0   1   -   9
    # 1   0   1   0   -   10
    # 1   0   1   1   -   11
    # 1   1   0   0   -   12
    # 1   1   0   1   -   13
    # 1   1   1   0   -   14
    # 1   1   1   1   -   15
    
    # 1   0   1   0   -   10
    # 1   0   0   0   -   8
    #---------------------------
    # 1   0   0   0   -   8
    # 1   0   1   0   -   10
    # 0   0   1   0   -   2 
    # 1   0   0   1   -   9
    
    # 0 0 0 1 0 0 = 4
    # 0 0 0 1 0 0  = 4
    
      
       
a=16
print(a>>2)

# b=8

# print(a&b)
# print(a|b)
# print(a^b)














