# import pandas as pd

import pandas as pd

df = pd.read_csv('titanic.csv')

#print(df.to_string())
ages=df["Fare"]
print(ages.head(10))




# df = pd.DataFrame(

#     {

#         "Name": [

#             "Braund, Mr. Owen Harris",

#             "Allen, Mr. William Henry",

#             "Bonnell, Miss. Elizabeth",

#         ],

#         "Age": [22, 35, 58],

#         "Sex": ["male", "male", "female"],
#         "City": ["Dhaka", "Bogura", "Pabna"],

#     }

# )
# print(df)
# print(df['Name'])
# print(df['Age'])

# ages = pd.Series(["Dhaka", "Bogura", "Pabna"], name="City")
# print(ages)
# print(df['Age'].min())
# print(df.describe())

# titanic = pd.read_csv("titanic.csv")

# print(titanic.head())

# ages=titanic["Age"]
# print(ages.head(100))
# print(type(titanic["Age"]))
# print(titanic["Age"].shape)

# age_sex = titanic[["Age", "Sex"]]

# print(age_sex.head())

# print(type(titanic[["Age", "Sex"]]))

# print(titanic[["Age", "Sex"]].shape)

# above_35 = titanic[titanic["Age"] > 35]

# print(above_35.head(100))

# print(titanic["Age"] > 35)
# print(above_35.shape)

# I’m interested in the names of the passengers older than 35 years.

# adult_names = titanic.loc[titanic["Age"] > 35, "Name"]

# print(adult_names.head())

# I’m interested in rows 10 till 25 and columns 3 to 5.

# print(titanic.iloc[9:25, 2:5])








