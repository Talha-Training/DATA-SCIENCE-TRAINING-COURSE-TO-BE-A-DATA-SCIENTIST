# numbers = (20,30,40,50,60,70,90,50)
# total= 0

# for num in numbers:
#     total += num
# print("Total : ",total)


# numbers = [20,30,43,50,65,70,99,50]
# total= 0

# for num in numbers:
#     if num % 2 == 0:
#         total += num        
# print("Total : ",total)

# numbers = range(9)

# print(list(numbers))

# numbers = range(10,20)

# print(list(numbers))

# numbers = range(25,50,3)

# print(list(numbers))

# Factorial Number:
# fact = 1 
# n=9
# for x in range(1, n+1):
#     fact = fact * x
# print("Factorial of {} is {}".format(n, fact))

# for letter in 'Python':
#     if letter == 'h':
#         break
#     print("Current Letter :", letter) 
    

# var = 10
# while var > 0:
#     print("Current variable value:", var)
#     var = var-1
#     if var == 5:
#         break
# print("Good Bye!")


# for letter in 'Python':
#     # if letter == 'h':
#     print("Current Letter :", letter) 
#     continue
    
#     print("Hello") 

# var = 10
# while var > 0:
#     print("Current variable value:", var)
#     var = var-1
#     if var == 5:
#         continue
# print("Good Bye!")

# def add(x,y):
#     z=x+y
#     print(z)


# add(30,50)

def listToString(s):
 
    # initialize an empty string
    str1 = ""
 
    # traverse in the string
    for ele in s:
        str1 += ele
 
    # return string
    return str1



var = '''This is a string  
type of variables This is a string  
type of variables '''

# print(var[3:10])
l1 = list(var)

l1.insert(3,'M')


string=listToString(l1)


# var = str(l1)
print(string)



