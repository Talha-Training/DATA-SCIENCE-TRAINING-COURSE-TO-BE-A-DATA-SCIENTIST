a= input("Enter First Number:")
b= input("Enter Second Number:")

if a<b:
    print("A is Less than B")
    
else:
    print("A is Grater than B")
    
    
    