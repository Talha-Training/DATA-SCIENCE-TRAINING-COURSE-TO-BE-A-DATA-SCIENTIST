# def hello():
#     print("Hello Bangladesh")

# hello()

# def add(x,y):
#     z=x+y;
#     print(z)

# add(20,300)

def arithmetic(x,y,z=''):
    if z=='+':
        w=x+y
        print(w)
    elif z=='-':
        w=x-y
        print(w)
    else:
        w=x*y
        print(w)


arithmetic(10,20)

