# 1. Variable
# 2. Operators
# 3. Statements
#     a. Conditional Statements
#             i. if
#             ii. if else
#             iii. if elif
#             iv. switch
# #     b. Repeated Statements
#             1. for in 
#             2. while
#             3. do while
# 4. Array
# 5. Function
#Naming Standard
# 1. all names will be small latter 
# 2. For 2 or more words you can use _
# 3. names should be meaning full 

#Variable writing Rules
# 1. [A-Z a-z 0-9 _ = 63]
# 2. [You can not start variable name with a number]

# student_name="Sarbon Rahman"
# age=15
# status=True

# print(student_name)

# student_name="Parbon Rahman"

# print(student_name)

# Python Operators
# 1. Arithmetic OP
# 2. Assignment OP
# 3. Comparison Operators
# 4. Logical Operators
# 5. Identity Operators
# 6. membership Op
# 7. Bitwise OP

#1. Arithmetic OP: + - * / % ** //
# print(10//3)
#2. Assignment OP: = += -= *= /= %= **= //=
# a=10
# b=2
# a**=b
# print(a)
#3. Conditional OP: == != > < >= <=
a=10
b=11
print(a!=b) 



