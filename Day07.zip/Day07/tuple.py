# tuple_01=(3,5,'b')
# tuple_02=(10,50,'c','m')
# tuple_03=tuple_01 + tuple_02
# tuple_03=tuple_01 * 2 + tuple_02
# print(3 in tuple_03)

# tuple_01[1]=100
# print(tuple_03[:])

# tuple_01=('c','g','a','m','b','e','d')

# list_01=list(tuple_01)
# list_01[3]='n'
# list_01.append('p')
# list_01.insert(2,'q')

# print(list_01)

# tuple_01=tuple(list_01)
# tuple_01[3]=90
# print(tuple_01)
#Tuple Unpack

# tup1=(20,40,60,10)
# x,y,z,m=tup1
# x,*y=tup1
# *x,y,z=tup1

# print("x:",x,"y:",y,"z:",z)

tup1=(10,25,12,10,-21,10,100,10)
# tup2=(3,4,5,6,7)
# for num in tup1:
    # print(num, end = '/')
# tup3=tup1+tup2
# tup1 +=tup2
# tup3=sum((tup1,tup2),())
# print(tup3)

# print(tup1.index(10))

print(tup1.count(10))














