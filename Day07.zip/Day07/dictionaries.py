capital={"Bangladesh":"Dhaka","India":"Dellhi","Pakisthan":"Islamabad","Nepal":"Katmundu"}
# capital['Nepal']="Catmindu"
# capital['USA']='Weasinton'
city={"USA":"New York","Pakistha'":"Lahor","Bangladesh":"Rajshahi"}
capital.update(city)
print(capital)