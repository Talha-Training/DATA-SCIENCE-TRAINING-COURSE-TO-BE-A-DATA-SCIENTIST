# 1. List 
# 2. Touple
# 3. Dictonary 

#List 

data = [100,'Saahil',True, 50.5,'Shafana',300,56,87,'Alam','Kamal',False]

# print(data[:4])
# print(data)
# data[7]="Bangladesh"
# print(data)
# data[10]="Nepal"
# print(data)
# print(data[10])
# list2=['Rahim','Karim']
# data[2:4]=list2
# print(data)


# data.append("Shahed")
# print(data)
# data.insert(2,'Modon')
# print(data)

# thislist = ['apple','banana','cherry','banana','pinaple']

# secondlist = ['mango','pinaple','papaya']

# thislist.extend(secondlist)
# print(thislist)

# thislist.remove('banana')
# thislist.pop(3)
# thislist.pop()
# del thislist[0]
# thislist.clear()
# print(thislist)

thislist = ['apple','banana','cherry','banana','pinaple','apple','banana','cherry','banana','pinaple']

for x in thislist:
    print(x)



